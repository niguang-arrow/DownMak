function res=lt(X,Y)
res=lt(X.data, Y.data);
end
            