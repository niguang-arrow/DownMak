function res=mpower(X,Y)
res=mpower(X.data, Y.data);
end
            