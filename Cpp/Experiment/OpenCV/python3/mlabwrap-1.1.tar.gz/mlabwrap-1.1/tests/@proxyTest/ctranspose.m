function res=ctranspose(X)
res=ctranspose(X.data);
end
