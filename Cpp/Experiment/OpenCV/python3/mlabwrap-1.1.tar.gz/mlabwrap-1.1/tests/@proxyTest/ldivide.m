function res=ldivide(X,Y)
res=ldivide(X.data, Y.data);
end
            