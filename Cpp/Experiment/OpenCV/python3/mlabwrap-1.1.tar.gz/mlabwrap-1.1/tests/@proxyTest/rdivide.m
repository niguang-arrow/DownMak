function res=rdivide(X,Y)
res=rdivide(X.data, Y.data);
end
            