function X=proxyTest(a)
X.data = a;
X=class(X,'proxyTest');